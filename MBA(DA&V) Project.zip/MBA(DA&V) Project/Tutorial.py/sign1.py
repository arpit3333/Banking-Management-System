# Main Home Page
from register1 import*
from Database1 import*
user_signin = True  
print("Welcome To The Bank Of Bhopal") 
print("T.T.Nagar Branch")


while True :
    try :
        register = int(input("1.SignUp\n"
                            "2.SignIn\n"
                            "3.Exist")) 
        if register == 1 :
            SingUp()
        elif register == 2 :
            user = SingIn()
            user_signin = True
            break
        elif register == 3 :
            print("Thanks for visiting Bank of Bhopal...")
            quit()
        else :
            print("Error! Please enter the value in range 1-3")   
 
    except ValueError :
        print("Error! Enter the numeric value...") 
        break

account_number = cur.execute(f"SELECT account_number FROM customers WHERE username = '{user}';")
existing_acc2 = cur.fetchone()

while user_signin :

    print(f"Welcome {user.capitalize()} choose your banking service option.") 

    try :
        service = int(input("1.Balance Enquiry\n"
                            "2.Cash Deposit\n"
                            "3.Cash Withdraw\n"
                            "4.Fund Transfer")) 
        if service >=1 and service <= 4 : 
                if service == 1 :
                            bnkobj = Bank(user , existing_acc2[0]) 
                            bnkobj.balance_enquiry()
        
                elif service == 2 :
                    while True :
                        try :
                            amount_dep = int(input("Enter the amount :: ")) 
                            bnkobj = Bank(user , existing_acc2[0])
                            bnkobj.deposite(amount_dep) 
                            break 
                        except ValueError :
                            print("Error! enter the numeric value") 
                            continue
                    
                elif service == 3 :
                    while True :
                        try :
                            amount_wd = int(input("Enter the amount :: ")) 
                            bnkobj = Bank(user , existing_acc2[0])
                            bnkobj.withdraw(amount_wd)  
                            break 
                            
                        except ValueError :
                            print("Error! enter the numeric value") 
                            continue
                
                elif service == 4 :
                    while True :
                        try :
                            reciever = int(input("Enter the reciever account_number :: "))
                            amount_ft = int(input("Enter the amount :: ")) 
                            bnkobj = Bank(user , existing_acc2[0])
                            bnkobj.fundtransfer(amount_ft , reciever)    
                            break
                            
                        except ValueError :
                            print("Error! enter the numeric value") 
                            continue
        
        else :
            print("Error! Please enter the value in range 1-4")   
 
    except ValueError :
        print("Error! Enter the numeric value...") 
        break
