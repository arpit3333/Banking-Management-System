# SignUp And SignIn
from Database1 import*
from customer_details1 import*
from bank_service1 import*
import random

def SingUp() :
    username = input("Create Username :: ")
    temp = cur.execute(f"SELECT username FROM customers WHERE username ='{username}';") 
    existing_user = cur.fetchone()
    if existing_user :
        print("User Already Exists...Please write another valid username")
    else :
        print("Username Created Successfully...You can proceed") 
        password = input("Create your Password :: ")
        name = input("Enter your Name :: ")
        age = input("Enter your Age :: ")
        city = input("Enter your City :: ") 
        while True : 
            account_number = random.randint(10000000 , 99999999)
            temp2 = cur.execute(f"SELECT password FROM customers WHERE username = '{username}';")
            existing_acc = cur.fetchone()
            if existing_acc :
                continue
            else :
                print(f"Account Number :: {account_number}")
                break 
        cusobj = Customer(username , password , name , age , city , account_number) 
        cusobj.createuser()
        bnkobj = Bank(username , account_number) 
        bnkobj.create_transaction_table()
    
if __name__ == "__main__" :
    SingUp()
        

def SingIn() :
    while True :
        username = input("Enter your Username :: ")
        temp = cur.execute(f"SELECT username FROM customers WHERE username ='{username}';") 
        existing_user = cur.fetchone()
        if existing_user :
            attempts = 3
            while attempts > 0 :
                    print("Welcome To Bank Of Bhopal") 
                    password = input("Enter your Password :: ")
                    temp_3 = cur.execute(f"SELECT password FROM customers WHERE username = '{username}';")
                    existing_pass = cur.fetchone()
                    if existing_pass[0] == password :
                        print("SignIN successfully...") 
                        return username
                    else : 
                        attempts = attempts - 1
                        print(f"Wrong Password! You Have Left {attempts} Attempts...")   

            else :
                print("Maximum attempts reached..Please try again later.")
                quit()
        else :
            print("Enter Valid Username")
            continue

if __name__ == "__main__" :
    SingIn()
        
        
            
             


        
       

                
            
            
        
    