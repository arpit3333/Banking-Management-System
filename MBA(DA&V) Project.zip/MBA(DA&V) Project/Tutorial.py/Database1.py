# Database Creation 
import psycopg2 
# Connection Parameter
hostname = 'localhost'
dbname = 'bank'
username = 'postgres'
psw ='ARPIT' 
port_id = 5432   

try :
    # Estblishing Connection
    conn = psycopg2.connect(
           host = hostname ,
           database = dbname ,
           user = username ,
           password = psw , 
           port = port_id)

    # Creating a cursor for the querry execution 
    cur = conn.cursor()
    def createtable() :
        create_script = ''' CREATE TABLE IF NOT EXISTS customers 
                        (
                         username varchar(50) NOT NULL ,
                         password varchar(50) NOT NULL ,
                         name char(50) NOT NULL ,
                         age int8 NOT NULL , 
                         city char(50) ,
                         balance int8 ,
                         account_number int8 NOT NULL 
                        ) '''
        # Creating a cursor to execute querry
        cur.execute(create_script) 
        conn.commit()
        print("Table Created Successfully...") 

    if __name__ == "__main__" :
        createtable()
       
except psycopg2.Error as e :
    print("Error :: " , e)
 


