# Bank Serices
from Database1 import*
import datetime

class Bank :
    def __init__(self , username , account_number) :
        self.username = username
        self.account_number = account_number

    def create_transaction_table(self) :
        # Parameterised Querry
        cur.execute(f"CREATE TABLE IF NOT EXISTS {self.username}_transaction"
                    "( timedate varchar(30) NOT NULL , "
                    "account_number int8 NOT NULL , "
                    "remark varchar(50) ," 
                    "amount int8)"
                    ) 
        conn.commit()

    def balance_enquiry(self) :
        temp_3 = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';") 
        existing_temp3 = cur.fetchone() 
        print(f"{self.username} available balance is :: {existing_temp3[0]}") 
        
    def deposite(self , amount_dep) :
        temp_4 = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';")
        existing_tem_4 = cur.fetchone()
        existing_tem4 = existing_tem_4[0] + amount_dep
        update_balance = cur.execute(f"UPDATE customers SET balance = '{existing_tem4}' WHERE username = '{self.username}';")
        self.balance_enquiry()
        cur.execute(f"INSERT INTO {self.username}_transaction VALUES ("
                    f"'{datetime.datetime.now()}',"
                    f"'{self.account_number}',"
                    f"'Amount Deposited',"
                    f"'{amount_dep}')") 
        conn.commit()

        print(f"{self.username} Amount is Successfully deposited in your account number {self.account_number}")
        
    def withdraw(self , amount_wd) :
        temp_5 = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';")
        existing_tem_5 = cur.fetchone()
        existing_tem5 = existing_tem_5[0] - amount_wd
        update_balance = cur.execute(f"UPDATE customers SET balance = '{existing_tem5}' WHERE username = '{self.username}';")
        self.balance_enquiry()
        cur.execute(f"INSERT INTO {self.username}_transaction VALUES ("
                    f"'{datetime.datetime.now()}',"
                    f"'{self.account_number}',"
                    f"'Amount Withdraw',"
                    f"'{amount_wd}')") 
        conn.commit()

        print(f"{self.username} Amount is Successfully withdraw from your account number {self.account_number}")
        
    def fundtransfer(self , amount_ft , reciever) : 
        temp_6 = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';")
        temp_reciever = cur.execute(f"SELECT balance FROM customers WHERE account_number = '{reciever}';")
        existing_tem_6 = cur.fetchone()
        existing_tem6 = existing_tem_6[0] - amount_ft 
        existing_reciever = existing_reciever + amount_ft  
        update_balance = cur.execute(f"UPDATE customers SET balance = '{existing_tem6}' WHERE username = '{self.username}';")
        self.balance_enquiry() 
        cur.execute(f"INSERT INTO {self.username}_transaction VALUES ("
                    f"'{datetime.datetime.now()}',"
                    f"'{self.account_number}',"
                    f"'Fund Tranfer to account_number {reciever}',"
                    f"'{amount_ft}')")  
        conn.commit()

        print(f"{self.username} Amount is Successfully transfer to the account number {reciever}") 
        
    

        