import psycopg2

# Connection Parameter 
hostname = 'localhost'
dbname = 'bank_data'
username = 'postgres'
psw = 'ARPIT'
port_id = 5432

try :
    # Establish Connection To Database.
    conn = psycopg2.connect(
        host = hostname ,
        database = dbname ,
        user = username ,
        password = psw ,
        port = port_id)
    
    # Create a cursor to execute the SQL commands.
    cur = conn.cursor() 

    # Function To Create customers table.
    def createcustomer_table() :
        # SQL statement to create the customers table if it doesn't exist.
        create_script = '''  CREATE TABLE IF NOT EXISTS customers(
                            username varchar(50) NOT NULL ,
                            password varchar(50) NOT NULL , 
                            name char(50) NOT NULL ,
                            age int8 NOT NULL ,
                            city char(50) NOT NULL ,
                            balance int8 NOT NULL , 
                            account_number varchar(50) ,
                            status BOOLEAN )'''
        #Execute SQL command to create the table
        cur.execute(create_script) 
        # Commit the Transaction
        conn.commit() 
        print("Table Created Successfully...")

    # Call the function to create a customers table
    if __name__ == "__main__" :
        createcustomer_table() 

except psycopg2.Error as e :
    print("Error in connecting to the database :" , e) 


