# Customer Details 
from database import* 
class Customer :
    def __init__(self , username , password , name , age , city , account_number) :
        self.username = username 
        self.password = password
        self.name = name 
        self.age = age
        self.city = city
        self.account_number = account_number 
    
    def createuser(self) : 
        temp = cur.execute(f"INSERT INTO customers VALUES('{self.username}' , '{self.password}' , '{self.name}' , '{self.age}' , '{self.city}' , 0 ,  '{self.account_number}' , True);")
        conn.commit() 
        
