from register import *
from database import *
from bank_services import *
status = False
print("Welcome To Bank Of Bhopal.")
print("T.T.Nagar Branch") 
while True :
    try :
        register = int(input("1. SignUp\n"
                             "2. SignIn\n"
                             "3. Exist")) 
        if register == 1 or register == 2 :
            if register == 1 :
                SignUp() 
            if register == 2 :
                user = SignIn() 
                status = True
                break 
    
        elif register == 3 :
            print("Thanks for visiting...")
            quit()
                  
        else :
            print("Please Enter Valid Input From Options.") 
        
    except ValueError :
        print("Invalid Input Try Again with Numbers")
        break

account_number = cur.execute(f"SELECT account_number FROM customers WHERE username = '{user}';")
existing_acc = cur.fetchone()
  
while status :

    print(f"Welcome {user} Choose Your Banking Service\n")    

    try :
        facility = int(input("1. Balance Enquiry\n"
                             "2. Cash Deposite\n"
                             "3. Cash Withdraw\n"
                             "4. Fund Transfer")) 
        if facility >= 1 and facility <= 4 :
            if facility == 1 :
                while True :
                       bkobj = Bank(user , existing_acc[0]) 
                       bkobj.balanceenquiry() 
                       break     
            elif facility == 2 :
                while True :
                    try :
                       amount_dep = int(input("Enter amount to deposite :: "))
                       bkobj = Bank(user , existing_acc[0]) 
                       bkobj.deposite(amount_dep) 
                       break     
                    except ValueError :
                         print("Enter Valid Input i.e Numeric")  
                         continue 
                    
            elif facility == 3 :
                while True :
                    try :
                        amount_wd = int(input("Enter amount to withdraw :: "))
                        bkobj = Bank(user , existing_acc[0]) 
                        bkobj.withdraw(amount_wd) 
                        break     
                    except ValueError :
                        print("Enter Valid Input i.e Numeric")  
                        continue 
                
            elif facility == 4 :
                while True :
                    try :
                        reciever = int(input("Enter the Reciever Account Number :: "))
                        amount_trf = int(input("Enter Money To Transfer :: ")) 
                        bkobj = Bank(user , existing_acc[0]) 
                        bkobj.fundtransfer(reciever , amount_trf)  
                        break     
                    except ValueError :
                        print("Enter Valid Input i.e Numeric") 
                        continue
        else :
            print("Error! Enter the number in range 1-4") 
        
    except ValueError :
        print("Invalid Input Try Again with Numbers")
        continue

    