# Bank Services
from database import *
import datetime
class Bank :
    def __init__(self , username , account_number) :
        self.username = username
        self.account_number = account_number  

    def create_transaction_table(self) :
        # Parameterized Query  
        temp = cur.execute(

                           f"CREATE TABLE IF NOT EXISTS {self.username}_transaction"
                             "(timedate varchar(30) ,"
                             "account_number int8 ,"
                             "remarks varchar(30) ,"
                             "amount int8 )"
                           
                           ) 
        conn.commit()

    def balanceenquiry(self) :
        temp = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';")
        existing_temp = cur.fetchone()
        print(f"{self.username} Balance is {existing_temp[0]}") 
      
    def deposite(self , amount) :
        temp = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';")
        existing_value = cur.fetchone() 
        existing_value1 = existing_value[0] + amount 
        cur.execute(f"UPDATE customers SET balance = '{existing_value1}'WHERE username = '{self.username}';")
        self.balanceenquiry()
        cur.execute(f"INSERT INTO {self.username}_transaction VALUES("
                    f"'{datetime.datetime.now()}',"
                    f"'{self.account_number}',"
                    f"'Amount Deposit',"
                    f"'{amount}')") 
        conn.commit()
        print(f"{self.username} Amount Is Successfully Deposited into Your Account {self.account_number}")

    def withdraw(self , amount) :
        temp = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';")
        existing_value = cur.fetchone() 
        if amount > existing_value[0] :
            print("Insufficient Balance.") 
        else :
            existing_value2 = existing_value[0] - amount 
            cur.execute(f"UPDATE customers SET balance = '{existing_value2}'WHERE username = '{self.username}';")
            self.balanceenquiry()
            cur.execute(f"INSERT INTO {self.username}_transaction VALUES("
                        f"'{datetime.datetime.now()}',"
                        f"'{self.account_number}',"
                        f"'Amount Withdraw',"
                        f"'{amount}')")  
            conn.commit()
            print(f"{self.username} Amount Is Successfully Withdraw from Your Account {self.account_number}")    

    def fundtransfer(self , reciever , amount_trf) :
        temp = cur.execute(f"SELECT balance FROM customers WHERE username = '{self.username}';")
        existing_temp = cur.fetchone() 
        temp2 = cur.execute(f"SELECT balance FROM customers WHERE account_number = '{reciever}';")
        existing_temp2 = cur.fetchone() 
        if amount_trf > existing_temp[0] :
            print("Insufficient Balance.")  
        else :
            existing_tempnew = existing_temp[0] - amount_trf
            existing_temp2new = existing_temp2[0] + amount_trf  
            cur.execute(f"UPDATE customers SET balance = '{existing_tempnew}'WHERE username = '{self.username}';")
            cur.execute(f"UPDATE customers SET balance = '{existing_temp2new}'WHERE account_number  = '{reciever}';") 
            self.balanceenquiry()
            cur.execute(f"INSERT INTO {self.username}_transaction VALUES("
                        f"'{datetime.datetime.now()}',"
                        f"'{self.account_number}',"
                        f"'Fund Transfer -> {reciever}',"  
                        f"'{amount_trf}')")     
            conn.commit()
            print(f"{self.username} Amount Is Successfully Withdraw from Your Account {self.account_number}") 
            print(f" Amount :: {amount_trf} transfer to reciever Account Number :: {reciever} ")    

  
       