# User Registration Signin/Signup

from bank_services import Bank
from customer_details import *
import random

def SignUp() :
    username = input("Create Username :: ") 
    temp = cur.execute(f"Select username From customers WHERE username = '{username}';")
    existing_user = cur.fetchone() 

    if existing_user :
        print("Username Already Exists.")
        return
    else :
        print("Username is created successfully , Please Proceed.") 
        password = input("Enter Your Password : ") 
        name = input("Enter Your Name : ") 
        age = input("Enter Your Age : ") 
        city = input("Enter Your City : ") 
        while True :
            account_number = random.randint(10000000 , 99999999) 
            temp = cur.execute(f"SELECT account_number FROM customers WHERE account_number = '{account_number}';") 
            existing_acc = cur.fetchone()
            if existing_acc :
                continue
            else :
                print("Account Number :: " , account_number)
                break 
            
    cobj = Customer(username , password , name , age , city , account_number) 
    cobj.createuser()
    Bkobj = Bank(username , account_number) 
    Bkobj.create_transaction_table()

if __name__ == "__main__" :
    SignUp()

def SignIn() : 
    while True :
        username = input("Enter the Username :: ") 
        temp = cur.execute(f"Select username From customers WHERE username = '{username}';")
        existing_user = cur.fetchone() 
        if existing_user :
            attempts = 3
            while attempts > 0 :
                print("Welcome To The Bank Of Bhopal") 
                password = input("Enter the password :: ") 
                temp = cur.execute(f"Select password From customers WHERE username = '{username}';") 
                existing_pass = cur.fetchone() 
                if existing_pass[0] == password :  
                    print("Sign In Successfully")
                    return username 
                else :
                    attempts = attempts - 1
                    print("Wrong Password ! Attempts left :: " , attempts)
                    
            else :
                print("Maximum attempts reached . Please try again later.")
                print("Thanks For Visiting Bank Of Bhopal...") 
                quit()    
         
        else :
             print("Enter Correct Username.") 
             continue
        
if __name__ == "__main__" :
            SignIn()
    

    


